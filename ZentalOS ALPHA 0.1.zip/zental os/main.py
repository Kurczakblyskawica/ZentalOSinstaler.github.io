import pygame
import os
import subprocess
import webbrowser

pygame.init()

nrbg = 1

screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)

font = pygame.font.SysFont("Arial", 14)
font_render = font.render("Microsoft egde", True, (255, 255, 255))

SZEROKOSC = screen.get_width()
WYSOKOSC = screen.get_height()

wlaczony = True

# =========================
# Stan aplikacji
# =========================

ustawienia_otwarte = False
folderopen = False
shopopen = False


# =========================
# Grafiki
# =========================

folderinterfacecon = pygame.image.load(
    "Grafiki/Folder_interface.png"
).convert_alpha()

folderiterfacefinal = pygame.transform.scale(
    folderinterfacecon,
    (700, 500)
)


pasekzadanObraz = pygame.image.load(
    "Grafiki/pasek.png"
).convert_alpha()

pasekfinal = pygame.transform.scale(
    pasekzadanObraz,
    (1000, 170)
)


shutdowniconcon = pygame.image.load(
    "ikons/shutdown.png"
).convert_alpha()

shutdowniconfinal = pygame.transform.scale(
    shutdowniconcon,
    (50, 50)
)


terminaliconcon = pygame.image.load(
    "ikons/terminal.png"
).convert_alpha()

terminaliconfinal = pygame.transform.scale(
    terminaliconcon,
    (50, 50)
)


gegdeiconcon = pygame.image.load(
    "ikons/egdeicon.png"
).convert_alpha()

egdeiconfinal = pygame.transform.scale(
    gegdeiconcon,
    (60, 60)
)


foldericoncon = pygame.image.load(
    "ikons/folder.png"
).convert_alpha()

foldericonfinal = pygame.transform.scale(
    foldericoncon,
    (60, 60)
)


# =========================
# Teksty
# =========================

textfoldernamerender = font.render(
    "moje projekty",
    True,
    (255, 255, 255)
)

textustawienia = font.render(
    "ustawienia",
    True,
    (255, 255, 255)
)


mojeProjektyTekst = font.render(
    "simple calculator",
    True,
    (255, 255, 255)
)

simple_calculator_rect = mojeProjektyTekst.get_rect(
    topleft=(400, 320)
)


# =========================
# Close
# =========================

closeappiconcon = pygame.image.load(
    "grafiki/closeapp.png"
).convert_alpha()

closeappiconfinal = pygame.transform.scale(
    closeappiconcon,
    (30, 30)
)


# =========================
# Shop
# =========================

shopappiconcon = pygame.image.load(
    "ikons/shop.png"
).convert_alpha()

shopappiconfinal = pygame.transform.scale(
    shopappiconcon,
    (60, 60)
)

shopappname = font.render(
    "Zen Shop",
    True,
    (255, 255, 255)
)


# =========================
# Główna pętla
# =========================

while wlaczony:

    # =========================
    # Tło
    # =========================

    tloObrazek = pygame.image.load(
        f"backgrouds/bg {nrbg}.png"
    ).convert()

    tlo = pygame.transform.scale(
        tloObrazek,
        (SZEROKOSC, WYSOKOSC)
    )

    screen.blit(tlo, (0, 0))


    # =========================
    # Pasek zadań
    # =========================

    screen.blit(pasekfinal, (150, 620))

    screen.blit(
        shutdowniconfinal,
        (200, 680)
    )

    screen.blit(
        terminaliconfinal,
        (300, 676)
    )


    # =========================
    # Edge
    # =========================

    screen.blit(
        egdeiconfinal,
        (30, 30)
    )

    screen.blit(
        font_render,
        (30, 100)
    )


    # =========================
    # Folder
    # =========================

    screen.blit(
        foldericonfinal,
        (30, 130)
    )

    screen.blit(
        textfoldernamerender,
        (30, 200)
    )


    # =========================
    # Ustawienia
    # =========================

    ustawieniaiconcon = pygame.image.load(
        "ikons/ustawienia.png"
    ).convert_alpha()

    ustawieniaikonfinal = pygame.transform.scale(
        ustawieniaiconcon,
        (50, 50)
    )

    screen.blit(
        ustawieniaikonfinal,
        (400, 680)
    )


    # =========================
    # Shop
    # =========================

    screen.blit(
        shopappiconfinal,
        (30, 230)
    )

    screen.blit(
        shopappname,
        (30, 290)
    )


    # =========================================================
    # OKNO USTAWIEŃ
    # =========================================================

    if ustawienia_otwarte:

        ustawienia_rect = folderiterfacefinal.get_rect(
            center=(
                SZEROKOSC // 2,
                WYSOKOSC // 2
            )
        )

        screen.blit(
            folderiterfacefinal,
            ustawienia_rect
        )

        button_font = pygame.font.SysFont(
            "Arial",
            30
        )

        button_text = button_font.render(
            "<-",
            True,
            (255, 255, 255)
        )

        screen.blit(
            button_text,
            (450, 250)
        )


        button_text1 = button_font.render(
            "->",
            True,
            (255, 255, 255)
        )

        screen.blit(
            button_text1,
            (700, 250)
        )


        screen.blit(
            textustawienia,
            (580, 190)
        )


        tekstfont = pygame.font.SysFont(
            "Arial",
            30
        )

        tekst_text = tekstfont.render(
            f"tapeta nr: {nrbg}",
            True,
            (255, 255, 255)
        )

        screen.blit(
            tekst_text,
            (500, 300)
        )


        # X
        screen.blit(
            closeappiconfinal,
            (900, 180)
        )


    # =========================================================
    # FOLDER
    # =========================================================

    if folderopen:

        folder_rect = folderiterfacefinal.get_rect(
            center=(
                SZEROKOSC // 2,
                WYSOKOSC // 2
            )
        )

        nazwaugory = font.render(
            "Moje Projekty",
            True,
            (255, 255, 255)
        )

        screen.blit(
            folderiterfacefinal,
            folder_rect
        )

        screen.blit(
            egdeiconfinal,
            (400, 250)
        )

        screen.blit(
            mojeProjektyTekst,
            simple_calculator_rect.topleft
        )

        screen.blit(
            nazwaugory,
            (580, 190)
        )

        # X
        screen.blit(
            closeappiconfinal,
            (900, 180)
        )


    # =========================================================
    # SHOP
    # =========================================================

    if shopopen:

        folder_rect = folderiterfacefinal.get_rect(
            center=(
                SZEROKOSC // 2,
                WYSOKOSC // 2
            )
        )

        nazwaugory = font.render(
            "Zen Shop",
            True,
            (255, 255, 255)
        )

        screen.blit(
            folderiterfacefinal,
            folder_rect
        )

        screen.blit(
            nazwaugory,
            (580, 190)
        )

        # X
        screen.blit(
            closeappiconfinal,
            (900, 180)
        )


    # =========================================================
    # KLIKNIĘCIA
    # =========================================================

    for event in pygame.event.get():

        if event.type == pygame.MOUSEBUTTONDOWN:

            if event.button == 1:

                mouse_x, mouse_y = pygame.mouse.get_pos()


                # =================================================
                # X - ZAMYKANIE OTWARTEGO OKNA
                # =================================================

                if (
                    900 <= mouse_x <= 930
                    and
                    180 <= mouse_y <= 210
                ):

                    if folderopen:
                        folderopen = False

                    elif ustawienia_otwarte:
                        ustawienia_otwarte = False

                    elif shopopen:
                        shopopen = False


                # =================================================
                # SHUTDOWN
                # =================================================

                elif (
                    200 <= mouse_x <= 250
                    and
                    680 <= mouse_y <= 730
                ):

                    wlaczony = False


                # =================================================
                # TERMINAL
                # =================================================

                elif (
                    300 <= mouse_x <= 350
                    and
                    676 <= mouse_y <= 726
                ):

                    subprocess.Popen(
                        ["python", "terminal.py"],
                        creationflags=subprocess.CREATE_NEW_CONSOLE
                    )


                # =================================================
                # EDGE
                # =================================================

                elif (
                    30 <= mouse_x <= 90
                    and
                    30 <= mouse_y <= 90
                ):

                    webbrowser.open(
                        "https://www.bing.com/"
                    )


                # =================================================
                # USTAWIENIA
                # =================================================

                elif (
                    400 <= mouse_x <= 450
                    and
                    680 <= mouse_y <= 730
                ):

                    ustawienia_otwarte = True
                    folderopen = False
                    shopopen = False


                # =================================================
                # USTAWIENIA - POPRZEDNIA TAPETA
                # =================================================

                elif (
                    ustawienia_otwarte
                    and
                    450 <= mouse_x <= 500
                    and
                    250 <= mouse_y <= 285
                ):

                    if nrbg > 1:
                        nrbg -= 1
                    else:
                        nrbg = 3


                # =================================================
                # USTAWIENIA - NASTĘPNA TAPETA
                # =================================================

                elif (
                    ustawienia_otwarte
                    and
                    700 <= mouse_x <= 750
                    and
                    250 <= mouse_y <= 285
                ):

                    if nrbg < 3:
                        nrbg += 1
                    else:
                        nrbg = 1


                # =================================================
                # SHOP
                # =================================================

                elif (
                    30 <= mouse_x <= 90
                    and
                    230 <= mouse_y <= 290
                ):

                    shopopen = True
                    folderopen = False
                    ustawienia_otwarte = False


                # =================================================
                # FOLDER
                # =================================================

                elif (
                    30 <= mouse_x <= 90
                    and
                    130 <= mouse_y <= 220
                ):

                    folderopen = True
                    shopopen = False
                    ustawienia_otwarte = False


                # =================================================
                # SIMPLE CALCULATOR
                # =================================================

                elif (
                    folderopen
                    and
                    simple_calculator_rect.collidepoint(
                        mouse_x,
                        mouse_y
                    )
                ):

                    webbrowser.open(
                        "calculatorr.html"
                    )


    # =========================
    # Odświeżenie ekranu
    # =========================

    pygame.display.flip()


pygame.quit()