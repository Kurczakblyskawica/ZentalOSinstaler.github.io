import os
import platform
import psutil
import GPUtil

import pygame
from datetime import datetime
import time

os.system("title Zental Shell")
# Włączenie kolorów w konsoli Windows
os.system("")

aktualny_czas = datetime.now().strftime("%H:%M:%S")





# Definicje kolorów (kody ANSI)
RED = "\033[31m"
BLUE = "\033[34m"
GREEN = "\033[32m"
CYAN = "\033[96m"
YELLOW = "\033[93m"
GREEN = "\033[92m"
WHITE = "\033[97m"
RESET = "\033[0m"

terminal = True
while terminal:
    aktualny_czas = datetime.now().strftime("%H:%M:%S")
    
    cmd = input(f"{CYAN}<zental OS>:{RESET} ")
    cmd1 = cmd.lower()
    if cmd1 == "help":
        print(f"{YELLOW}=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-")
        print("                                ")
        print("                                ")
        print("        ████████████            ")
        print("      ██                        ")
        print("    ██                          ")
        print("  ██                            ")
        print("  ██                      ██    ")
        print("  ██                    ████████")
        print("  ██                  ██  ██  ██")
        print("  ██                      ██    ")
        print("    ██                    ██    ")
        print("      ████████████████████      ")
        print("                                ")
        print("                                ")
        print("                                ")
        print("                                ")
        print(f"=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-{RESET}")
        print(f"{GREEN}Pomoc{RESET}")
        print(f"{WHITE}cls - czyści terminal{RESET}")
        print(f"{WHITE}exit - wychodzi z terminala{RESET}")
        print(f"{WHITE}calc - kalkulator")
        print(f"{WHITE}info - podaje informacje ")
        print(f"{YELLOW}=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-{RESET}")
    elif cmd1 == "cls":
        os.system("cls")
    elif cmd1 == "exit":
        print(f"{CYAN}bye!{RESET}")
        input()
        terminal = False
    elif cmd1 == "calc":
        print(f"{GREEN}=-=-=-=-=-=-=-=-=-=")
        operator = input("Operator: ")
        print("=-=-=-=-=-=-=-=-=-=")
        if operator == "+":
            print("=-=-=-=-=-=-=-=-=-=")
            try:
             a = int(input("liczba a: "))
             b = int(input("liczba b: "))
             wynik = a + b
             print(f"{a} + {b} = {wynik}")
            except:
                print("Coś poszło nie tak!")
            print(f"=-=-=-=-=-=-=-=-=-= {RESET}")
        elif operator == "-":
            print("=-=-=-=-=-=-=-=-=-=")
            try:
             a = int(input("liczba a: "))
             b = int(input("liczba b: "))
             wynik = a - b
             print(f"{a} - {b} = {wynik}")
            except:
                print("Coś poszło nie tak!")
            print(f"=-=-=-=-=-=-=-=-=-= {RESET}")
        elif operator == "*":
           try:
              a = int(input("Liczba a: "))
              b = int(input("liczba b : "))
              wynik = a * b
              print(f"{a} * {b} = {wynik}")
           except:
              print("Coś poszło nie tak!")

        elif operator == "/":
           try:
              a = int(input("liczba a: "))
              b = int(input("liczba b: "))
              wynik = a / b
              print(f"{a} / {b} = { wynik}")
           except: 
              print("Coś poszło nie tak !")
        else:
           print(f"{RED}Nieznany operator! {RESET}")
           print(f"{GREEN}=-=-=-=-=-=-=-=-=-=-=-=- {RESET}")

    elif cmd1 == "info":
       gpus = GPUtil.getGPUs()
       print(f"{YELLOW}=-=-=-=-=-=-=-=-=-=-=-=-=")
       print("                                 |")
       print("                                 |")
       print("        ████████████             |              [nazwa OS]: Zental")
       print("      ██                         |              -------------------")
       print("    ██                           |              [Wersja]: ALPHA 0.1")
       print("  ██                             |              -------------------")
       print(f" ██                      ██     |             [Aktualny Czas]: {aktualny_czas}")
       print("  ██                    ██████   |             -------------------------------")
       print("  ██                  ██  ██  ██ |")
       print(f"  ██                      ██    |")             
       print("    ██                    ██     |")
       print("      ████████████████████       |")
       print("                                 |")
       print("                                 |")
       print("                                 |")
       print("                                 |")
       print(f"=-=-=-=-=-=-=-=-=-=-=-=-={RESET}")
    else:
       print(f"{RED}Nieznana komenda użyj komendy help")